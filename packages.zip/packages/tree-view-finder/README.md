# tree-view-finder package

Alter the TreeView to Mac OS finder like.

Press ctrl-alt-o to toggle this function or choose 'Toggle tree-view-finder' in
context menu on the TreeView.

 * Display size and date in the TreeView.
 * Sort entries by name, size or date.
 * Enter folder or open file with external program by double click.

![A screenshot 2](https://raw.githubusercontent.com/hanyazou/tree-view-finder/master/images/ScreenShot-0001.png)

![A screenshot](https://raw.githubusercontent.com/hanyazou/tree-view-finder/master/images/ScreenShot-0000.png)
