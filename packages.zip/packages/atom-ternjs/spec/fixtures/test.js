function test() {

  var foo = 'bar';
  foo = foo.trim();
}

test();
